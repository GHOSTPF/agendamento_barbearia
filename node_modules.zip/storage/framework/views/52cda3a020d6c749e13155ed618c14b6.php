<div>
    
</div>
<?php /**PATH C:\Users\pablo\crudagend\resources\views/livewire/money-input.blade.php ENDPATH**/ ?>