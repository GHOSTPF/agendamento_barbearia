<?php

namespace App\Livewire;

use App\Models\Note;
use Flux\Flux;
use Livewire\Component;

class CreateNote extends Component
{
    
    public $title;

    //public $content;
    public $barber;
    public $haircut;
    public $price;

    protected function rules()
    {
        return [
            'title' => 'required|string|max:255',
            'barber' => 'required|string|max:255', 
            'haircut' => 'required|string|max:255', 
            'price' => 'required|numeric|min:0',
            //'content' => 'required|string'
        ];
    }

    public function save()
    {
        $this->validate();
        //dd('ok');
        // Converte o preço para formato numérico
        $price = is_numeric($this->price) ? $this->price : 
                 (float) str_replace(['R$', ',', '.'], ['', '', ','], $this->price);

        // dd($this);

        Note::create([
            "title" => $this->title,
            "barber" => $this->barber,
            "haircut" => $this->haircut,
            "price" => $price,
            //"content" => $this->content,
        ]);

        $this->reset();

        Flux::modal('create-note')->close();

        session()->flash('success', 'Agendamento feito com sucesso');

        $this->redirectRoute('notes', navigate: true);

    }
    public function render()
    {
        return view('livewire.create-note');
    }
}
