<?php

namespace App\Livewire;

use App\Models\Note;
use Flux\Flux;
use Illuminate\Validation\Rule;
use Livewire\Attributes\On;
use Livewire\Component;

class EditNote extends Component
{
    public $title, $noteId, $barber, $haircut, $price;

    #[On('edit-note')]
    public function editNote($id)
    {
        $note = Note::findOrFail($id);
        $this->noteId = $id;
        $this->title = $note->title;
        $this->barber = $note->barber;
        $this->haircut = $note->haircut;
        $this->price = $this->formatPriceForInput($note->price);
        Flux::modal('edit-note')->show();
    }

    // Formata o preço para exibição no input (R$ 12,34)
    protected function formatPriceForInput($price)
    {
        return number_format($price, 2, ',', '.');
    }

    // Converte o preço do formato brasileiro para float (12,34 → 12.34)
    protected function formatPriceForDatabase($price)
    {
        if (is_numeric($price)) {
            return $price;
        }
        
        // Remove pontos de milhar e converte vírgula decimal para ponto
        return (float) str_replace(['.', ','], ['', '.'], $price);
    }

    public function update()
    {
        $validated = $this->validate([
            'title' => ['required', 'string', 'max:255'],
            'barber' => ['required', 'string', 'max:255'],
            'haircut' => ['required', 'string', 'max:255'],
            'price' => ['required', 'min:0'],
        ]);

        // Formata o preço antes de salvar
        $validated['price'] = $this->formatPriceForDatabase($validated['price']);

        Note::find($this->noteId)->update($validated);

        session()->flash('success', 'Agendamento editado com sucesso');
        Flux::modal('edit-note')->close();
        $this->redirectRoute('notes', navigate: true);
    }

    public function render()
    {
        return view('livewire.edit-note');
    }
}