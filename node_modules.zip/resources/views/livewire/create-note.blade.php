<div>
    <flux:modal name="create-note" class="md:w-900">
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">Criar agendamento</flux:heading>
                <flux:text class="mt-2">Crie o agendamento do Cliente.</flux:text>
            </div>

            <flux:input label="Cliente" wire:model="title" placeholder="Nome do Cliente" />
            <flux:input label="Barbeiro" wire:model="barber" placeholder="Nome do Barbeiro" />
            <flux:input label="Tipo de Corte" wire:model="haircut" placeholder="Tipo de corte/serviço" />
            <!-- <flux:input type="text" label="Preço" wire:model.lazy="price" placeholder="R$ 0,00"  step="0.01" min="0"/> -->
            <flux:input 
                type="text" 
                label="Preço" 
                wire:model.lazy="price" 
                placeholder="R$ 0,00"
                x-data="{
                    formatPrice() {
                        // Remove tudo que não é número
                        let value = this.$el.value.replace(/[^\d]/g, '');
                        // Converte para centavos
                        value = (value / 100).toLocaleString('pt-BR', {
                            style: 'currency',
                            currency: 'BRL',
                            minimumFractionDigits: 2
                        });
                        this.$el.value = value;
                        this.$wire.set('price', value.replace(/[^\d,]/g, '').replace(',', '.'));
                    }
                }"
                x-on:blur="formatPrice"
                x-on:input.debounce.500ms="formatPrice"
            />
            <!-- <flux:textarea label="Observações" wire:model="content" placeholder="Observações adicionais" /> -->

            <div class="flex">
                <flux:spacer />

                <flux:button type="submit" variant="primary" wire:click="save">Salvar</flux:button>
            </div>
        </div>
    </flux:modal>
</div>