<div class="relative mb-6 w-full">
    <flux:heading size="xl" level="1">{{ __('Configurações') }}</flux:heading>
    <flux:subheading size="lg" class="mb-6">{{ __('Gerencie seu perfil e as configurações da conta') }}</flux:subheading>
    <flux:separator variant="subtle" />
</div>
